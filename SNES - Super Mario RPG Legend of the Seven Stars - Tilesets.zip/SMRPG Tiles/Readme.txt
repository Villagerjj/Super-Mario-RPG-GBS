I didn't want to type this on all the sheets in order to preserve the transparency. MS Paint and all that.

Anyway, being tiles, a lot of these repeat, so I skipped a lot of repeat files. That might mean I forgot something, so if I did, email me at tonberry2000@gmail.com.
I also tried to make the image file names self-explanatory. If they're not, here are a few definitions;

MK = Mushroom Kingdom
Ext = Exterior
Int = Interior
Bows = Bowser's Keep

Some areas that reuse tiles include; 

Mario's Pad, Mushroom Way, Bandit's Way, Rose Way, Kero Sewers entrance, Tadpole Pond.
Rose Town, Marrymore, and the Mushroom Kingdom town interiors. For all exteriors, usually only the roof colors are different. Even Monstro Town uses the same tiles, but it has no roofs.
Moleville, the Land's End cliff, and Booster Pass.
Forest Maze caves, Belome Temple Caves.
